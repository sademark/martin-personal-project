/*
SQLyog Ultimate v11.33 (32 bit)
MySQL - 5.5.24-log : Database - mahasiswa
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mahasiswa` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mahasiswa`;

/*Table structure for table `tbl_dosen` */

DROP TABLE IF EXISTS `tbl_dosen`;

CREATE TABLE `tbl_dosen` (
  `nik` int(11) NOT NULL,
  `nama_dosen` varchar(100) DEFAULT NULL,
  `alamat_dosen` varchar(100) DEFAULT NULL,
  `tgl_lahir_dosen` date DEFAULT NULL,
  `telepon_dosen` int(11) DEFAULT NULL,
  `email_dosen` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nik`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_dosen` */

/*Table structure for table `tbl_jadwal` */

DROP TABLE IF EXISTS `tbl_jadwal`;

CREATE TABLE `tbl_jadwal` (
  `id_jadwal` int(11) NOT NULL,
  `tanggal_jadwal` datetime DEFAULT NULL,
  `nik` int(11) DEFAULT NULL,
  `nim` int(11) DEFAULT NULL,
  `id_jur` int(11) DEFAULT NULL,
  `id_matkul` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_krs` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_jadwal`),
  KEY `fk_nik` (`nik`),
  KEY `fn_nim` (`nim`),
  KEY `fk_idjur` (`id_jur`),
  KEY `fk_matkul` (`id_matkul`),
  KEY `fk_idkelas` (`id_kelas`),
  KEY `id_krs` (`id_krs`),
  CONSTRAINT `fk_idjur` FOREIGN KEY (`id_jur`) REFERENCES `tbl_jurusan` (`id_jur`),
  CONSTRAINT `fk_idkelas` FOREIGN KEY (`id_kelas`) REFERENCES `tbl_kelas` (`id_kelas`),
  CONSTRAINT `fk_matkul` FOREIGN KEY (`id_matkul`) REFERENCES `tbl_matkul` (`id_matkul`),
  CONSTRAINT `fk_nik` FOREIGN KEY (`nik`) REFERENCES `tbl_dosen` (`nik`),
  CONSTRAINT `fn_nim` FOREIGN KEY (`nim`) REFERENCES `tbl_mhs` (`nim`),
  CONSTRAINT `id_krs` FOREIGN KEY (`id_krs`) REFERENCES `tbl_krs` (`id_krs`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_jadwal` */

/*Table structure for table `tbl_jurusan` */

DROP TABLE IF EXISTS `tbl_jurusan`;

CREATE TABLE `tbl_jurusan` (
  `id_jur` int(11) NOT NULL,
  `nama_jur` varchar(50) DEFAULT NULL,
  `nim` int(11) DEFAULT NULL,
  `nik` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_jur`),
  KEY `tbl_jurusan_ibfk_1` (`nim`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_jurusan` */

/*Table structure for table `tbl_kelas` */

DROP TABLE IF EXISTS `tbl_kelas`;

CREATE TABLE `tbl_kelas` (
  `id_kelas` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kelas` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_kelas` */

/*Table structure for table `tbl_krs` */

DROP TABLE IF EXISTS `tbl_krs`;

CREATE TABLE `tbl_krs` (
  `id_krs` int(11) NOT NULL,
  `semester` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id_krs`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_krs` */

/*Table structure for table `tbl_matkul` */

DROP TABLE IF EXISTS `tbl_matkul`;

CREATE TABLE `tbl_matkul` (
  `id_matkul` int(11) NOT NULL,
  `nama_matkul` varchar(50) DEFAULT NULL,
  `nik` int(11) DEFAULT NULL,
  `nim` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_matkul`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_matkul` */

/*Table structure for table `tbl_mhs` */

DROP TABLE IF EXISTS `tbl_mhs`;

CREATE TABLE `tbl_mhs` (
  `nim` int(11) NOT NULL,
  `nama_mhs` varchar(50) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat_mhs` varchar(100) DEFAULT NULL,
  `telepon_mhs` int(11) DEFAULT NULL,
  `email_mhs` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nim`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_mhs` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
